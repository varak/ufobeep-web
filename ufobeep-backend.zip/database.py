import aiosqlite

DB_PATH = "sightings.db"

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS sightings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT,
                filepath TEXT,
                lat REAL,
                lon REAL,
                bearing REAL,
                timestamp TEXT,
                device_id TEXT
            )
        """)
        await db.commit()

async def save_sighting(filename, filepath, lat, lon, bearing, timestamp, device_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO sightings (filename, filepath, lat, lon, bearing, timestamp, device_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (filename, filepath, lat, lon, bearing, timestamp, device_id))
        await db.commit()