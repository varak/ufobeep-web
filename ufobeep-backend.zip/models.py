from pydantic import BaseModel

class Sighting(BaseModel):
    filename: str
    filepath: str
    lat: float
    lon: float
    bearing: float
    timestamp: str
    device_id: str