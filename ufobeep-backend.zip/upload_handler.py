import os
from fastapi import UploadFile
from datetime import datetime

UPLOAD_DIR = "static/uploads"

async def save_upload_file(file: UploadFile):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    filename = f"{datetime.utcnow().isoformat()}_{file.filename}"
    filepath = os.path.join(UPLOAD_DIR, filename)
    with open(filepath, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    return filepath